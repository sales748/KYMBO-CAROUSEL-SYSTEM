KYMBO carousels — every carousel that needs NO scene photography.

JPG 1080x1350 — post these

Batch-01-campaign/   c01-c12  (71 slides) — Fire Your Middleman, systemized
Batch-02-educational/ c13-c18 (36 slides) — c13-c16 educational, c17-c18 campaign

All 4:5. Slides are numbered in swipe order: cNN-s1 is the cover.
The organic/scene carousels are delivered separately, one at a time.
